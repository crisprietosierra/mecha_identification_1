% Purpose: This script allows to identify the dominant mechanisms 
% using the approach from Prieto et al (2020 - under review)
% Prieto, C., Kavetski, D., Le Vine, N., Álvarez, C., and Medina, R. (2020), 
% Identification of dominant hydrological mechanisms using Bayesian inference, multiple statistical hypothesis testing and flexible models, Water Resources Research
% ---
% inputs: the ensemble of hydrological models, model decisions, posterior
% probabilities of hydro models
% outputs: 1 if a mecha is identified as dominant for the saturated zone, 0 if it is not
% e.g. if the outputs is 1 0 0 0, means that mechanism 1 is identified as
% dominant and m2, m3 and m4 are not dominant
% ---
% programmers: Prieto, C., Kavetski, D., Le Vine, N.
% (C) Copyright 2021-2031  ---  Cristina Prieto, Dmitri Kavetski and Nataliya Le Vine  ---  All rights reserved
% ---
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% ---
clear all;
close all;
clc;
[a b]=xlsread('main_list_models_IDs_decisions_no_RE.xlsx');
ntotalMod=624;
% c=1;
% Ns=10000;
if(length(find(a(:,4)==1)))>0;
    Nmod1=(find(a(:,4)==1));
end
if(length(find(a(:,4)==2)))>0;
    Nmod2=(find(a(:,4)==2));
end
if(length(find(a(:,4)==3)))>0;
    Nmod3=(find(a(:,4)==3));
end
if(length(find(a(:,4)==4)))>0;
    Nmod4=(find(a(:,4)==4));
end
aux=zeros(1,length(unique(a(:,4))));
%for (i=1:Ns)
%   y1(i,:) = randsample(length(Nmod1),length(Nmod1),true);
%   y2(i,:) = randsample(length(Nmod2),length(Nmod2), true);
%   y3(i,:) = randsample(length(Nmod3),length(Nmod3),true);
%   y4(i,:) = randsample(length(Nmod4),length(Nmod4),true);
%end
path_ns=[pwd '\Nsamples\']
%   save([path_ns '\y1_arch2_rsmpl.mat'],'y1')
%	save([path_ns '\y2_arch2_rsmpl.mat'],'y2')
%	save([path_ns '\y3_arch2_rsmpl.mat'],'y3')
%   save([path_ns '\y4_arch2_rsmpl.mat'],'y4')
y1_10000=load([path_ns '\y1_arch2_rsmpl.mat'],'y1');
y2_10000=load([path_ns '\y2_arch2_rsmpl.mat'],'y2');
y3_10000=load([path_ns '\y3_arch2_rsmpl.mat'],'y3');
y4_10000=load([path_ns '\y4_arch2_rsmpl.mat'],'y4');
aux=zeros(1,length(unique(a(:,4))));
NW=load(['Post_all_models.mat']);
NW=NW.NW';
all_alpha=dlmread('alpha.txt')

for (i_alpha=1:length(all_alpha))
    for (i=1:Ns)
        y1=y1_10000.y1(i,:);
        y2=y2_10000.y2(i,:);
        y3=y3_10000.y3(i,:);
        y4=y4_10000.y4(i,:);
        if(length(find(a(:,4)==1)))>0;
            P1(i)=((1/length(unique(a(:,4))))/(length(Nmod1)/ntotalMod))*sum(NW(Nmod1(y1)));
        else
            P1(i)=0;
        end
        if(length(find(a(:,4)==2)))>0
            P2(i)=((1/length(unique(a(:,4))))/(length(Nmod2)/ntotalMod))*sum(NW(Nmod2(y2)));
        else
            P2(i)=0;
        end
        if(length(find(a(:,4)==3)))>0
            P3(i)=((1/length(unique(a(:,4))))/(length(Nmod3)/ntotalMod))*sum(NW(Nmod3(y3)));
        else
            P3(i)=0;
        end
        if(length(find(a(:,4)==4)))>0
            P4(i)=((1/length(unique(a(:,4))))/(length(Nmod4)/ntotalMod))*sum(NW(Nmod4(y4)));
        else
            P4(i)=0;
        end
        if(P1(i)==0)
            Pb1(i,1)=0;
        else
            Pb1(i,1)=(P1(i))/sum(P1(i)+P2(i)+P3(i)+P4(i));
        end
        if(P2(i)==0)
            Pb2(i,1)=0;
        else
            Pb2(i,1)=(P2(i))/sum(P1(i)+P2(i)+P3(i)+P4(i));
        end
        if(P3(i)==0)
            Pb3(i,1)=0;
        else
            Pb3(i,1)=(P3(i))/sum(P1(i)+P2(i)+P3(i)+P4(i));
        end
        if(P4(i)==0)
            Pb4(i,1)=0;
        else
            Pb4(i,1)=(P4(i))/sum(P1(i)+P2(i)+P3(i)+P4(i));
        end
    end
    for (i=1:Ns)
        t1(i)=[Pb1(i)];            
        t2(i)=[Pb2(i)];
        t3(i)=[Pb3(i)];
        t4(i)=[Pb4(i)];
    end
    save('t_a2.mat', 't1','t2','t3','t4')
    testtau=0.75;
    aux=zeros(1,length(unique(a(:,4))));
    alpha=all_alpha(i_alpha);
    if(length(find(t1>testtau))>=(1-alpha/length(unique(a(:,4))))*Ns)
        aux(1,1)=1;
    end
    if(length(find(t2>testtau))>=(1-alpha/length(unique(a(:,4))))*Ns)
        aux(1,2)=1;
    end
    if(length(find(t3>testtau))>=(1-alpha/length(unique(a(:,4))))*Ns)
        aux(1,3)=1;
    end
    if(length(find(t4>testtau))>=(1-alpha/length(unique(a(:,4))))*Ns)
        aux(1,4)=1;
    end
save ([pwd '\rsmpl_all_alphas\DominatMecha_arch2_' num2str(alpha) '.mat'],'aux')
end