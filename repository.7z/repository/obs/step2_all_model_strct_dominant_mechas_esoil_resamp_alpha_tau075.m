% Purpose: This script allows to identify the dominant mechanisms 
% using the approach from Prieto et al (2020 - under review)
% Prieto, C., Kavetski, D., Le Vine, N., Álvarez, C., and Medina, R. (2020), 
% Identification of dominant hydrological mechanisms using Bayesian inference, multiple statistical hypothesis testing and flexible models, Water Resources Research
% ---
% inputs: the ensemble of hydrological models, model decisions, posterior
% probabilities of hydro models
% outputs: 1 if a mecha is identified as dominant for the evporation, 0 if it is not
% e.g. if the outputs is 1 0, means that mechanism 1 is identified as
% dominant and m2 is not dominant
% ---
% programmers: Prieto, C., Kavetski, D., Le Vine, N.
% (C) Copyright 2021-2031  ---  Cristina Prieto, Dmitri Kavetski and Nataliya Le Vine  ---  All rights reserved
% ---
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
% ---clear all;
close all;
clc;
[a b]=xlsread('main_list_models_IDs_decisions_no_RE.xlsx');
ntotalMod=length(a(:,1));
Ns=10000;
if(length(find(a(:,7)==1)))>0;
    Nmod1=(find(a(:,7)==1));
end
if(length(find(a(:,7)==2)))>0;
    Nmod2=(find(a(:,7)==2));
end
%for (i=1:Ns)
%	y1(i,:) = randsample(length(Nmod1),length(Nmod1),true);
%	y2(i,:) = randsample(length(Nmod2),length(Nmod2), true);
%end
path_ns=[pwd '\Nsamples\']
%	save([path_ns '\y1_esoil_rsmpl.mat'],'y1')
%	save([path_ns '\y2_esoil_rsmpl.mat'],'y2')
y1_10000=load([path_ns '\y1_esoil_rsmpl.mat'],'y1');
y2_10000=load([path_ns '\y2_esoil_rsmpl.mat'],'y2');
NW=load(['Post_all_models.mat']);
NW=NW.NW';
aux=zeros(1,length(unique(a(:,7)))); 
all_alpha=dlmread('alpha.txt')

for (i_alpha=1:length(all_alpha))
    for (i=1:Ns)
        y1=y1_10000.y1(i,:);
        y2=y2_10000.y2(i,:);
        if(length(find(a(:,7)==1)))>0; 
            P1(i)=((1/length(unique(a(:,7))))/(length(Nmod1)/ntotalMod))*sum(NW(Nmod1(y1)));
        else
            P1(i)=0;
        end
        if(length(find(a(:,7)==2)))>0
            P2(i)=((1/length(unique(a(:,7))))/(length(Nmod2)/ntotalMod))*sum(NW(Nmod2(y2)));
        else
            P2(i)=0;
        end
        if(P1(i)==0)
            Pb1(i,1)=0;
        else
            Pb1(i,1)=(P1(i))/sum(P1(i)+P2(i));
        end
        if(P2(i)==0)
            Pb2(i,1)=0;
        else
        	Pb2(i,1)=(P2(i))/sum(P1(i)+P2(i));
        end
    end
    for (i=1:Ns)
        t1(i)=[Pb1(i)];            
        t2(i)=[Pb2(i)];
    end
    save('t_esoil.mat', 't1','t2')
    testtau=0.75;
    aux=zeros(1,length(unique(a(:,7))));
    alpha=all_alpha(i_alpha);
    if(length(find(t1>testtau))>=(1-alpha/length(unique(a(:,7))))*Ns)
        aux(1,1)=1;
    end
    if(length(find(t2>testtau))>=(1-alpha/length(unique(a(:,7))))*Ns)
        aux(1,2)=1;
    end
save ([pwd '\rsmpl_all_alphas\DominatMecha_evap_soil_' num2str(alpha) '.mat'],'aux')
end