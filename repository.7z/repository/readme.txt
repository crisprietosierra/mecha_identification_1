!============================================================================================================================================================
! Purpose: These folders provide data from the study of Prieto et al 2021 - under review
! Prieto, C., Kavetski, D., Le Vine, N., Álvarez, C., and Medina, R. (2019), 
! Identification of dominant hydrological mechanisms using Bayesian inference, multiple statistical hypothesis testing and flexible models, Water Resources Research
!============================================================================================================================================================

1. Folder "synthetic_cases":
      a) folder "reliability_and_power_for_each_experiment__lowerrors_mediumerrors_largeerrors":
		this folder contains .txt files with the values of:
		    	(i) reliability
			(ii) power
			(iii) true positives
			(iii) false positives
			(iv) false negatives
		for significance levels (alpha) Scenario error and process, and across all Scenarios
			
		each process is linked with the following sufixes:
			- a1     = unsaturated zone
			- a2     = saturated zone
			- esoil  = evaporation
			- interf = interflow
			- perc   = percoltion
			- rr     = surface runoff
			- rout   = routing

		e.g. alpha_r_p_tp_fp_fn_low_error_a1.txt provides the following information for the lowest error scenario for the processes in the unsaturted zone:
			- first column  = values of the significance levels
			- second column = reliability for each alpha
			- third column  = power for each alpha
			- fourth column = true positives for each alpha
			- fifth column  = false positives for each alpha
			- sixth column  = false negatives for each alpha
	b) folders "post_prob_small_errors_experiment__50rep624mods", "post_prob_medium_errors_experiment__50rep_624mod" and "post_prob_large_errors_experiment__50rep_624mod"
		These folders contains .txt files with the posterior probability for each hydrological model structure

		e.g. folder post_prob_small_errors_experiment__50rep624mods -> post_probabilities_all_models__low_error__rep_0001__.txt:
			contains 624 values corresponding to the posterior probability of each hydrological model structure
				
2) Folder "obs":
	a) c8z1_data_obs.txt
		- dates and obs data for the Leizarán catchment
	b) Post_all_models.txt
		- posterior probilities of each model
	c) .m files
		- codes to run the identification of dominant mechanisms in the Leizarán catchment for each hydro process
	d) mechas_time_periods_and_alpha_levels.xlsx
		- number of bootstraps where a mecha is identified as dominant for the 6 years and 12 years periods and for different significant levels
